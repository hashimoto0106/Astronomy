"This is automatically generated at package time.  Do not edit"
__vcs_revision__ = '91e90b60'
