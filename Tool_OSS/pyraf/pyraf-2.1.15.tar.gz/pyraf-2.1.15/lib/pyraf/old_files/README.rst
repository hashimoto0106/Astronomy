This directory contains old test files for Chris Sontag
to run his custom diagnostic tests.

These tests (as of March 2018), if applicable, have been
ported to the "tests" directory. The ones here are not
run by CI and will not be modified to be in sync with
the ported counterparts. Use them at your own risk.
