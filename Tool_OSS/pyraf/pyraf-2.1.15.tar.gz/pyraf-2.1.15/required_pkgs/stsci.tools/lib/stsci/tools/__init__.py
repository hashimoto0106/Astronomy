from __future__ import division  # confidence high
from .version import *


__vdate__ = __version_date__
