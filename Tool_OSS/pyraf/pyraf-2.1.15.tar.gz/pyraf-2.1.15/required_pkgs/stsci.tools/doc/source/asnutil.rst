*******************************
Association File Interpretation
*******************************
Association files serve as FITS tables which relate a set of input files to the generation of calibrated or combined products.  

.. automodule:: stsci.tools.asnutil
   :members:
   :undoc-members:

