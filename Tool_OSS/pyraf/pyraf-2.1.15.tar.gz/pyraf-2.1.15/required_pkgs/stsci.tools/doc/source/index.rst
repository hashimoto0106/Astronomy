.. stsci.tools documentation master file, created by
   sphinx-quickstart on Thu Oct  7 13:09:39 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to stsci.tools's documentation!
=======================================

The STSCI.TOOLS package in STScI_Python provides many functions for use by multiple software packages.

Contents:

.. toctree::
   :maxdepth: 2

   basicutils
   fitsutil
   imgutils
   analysis
   bitmask

Building a TEAL Interface for Tasks
-----------------------------------
.. toctree::

   teal_guide


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

