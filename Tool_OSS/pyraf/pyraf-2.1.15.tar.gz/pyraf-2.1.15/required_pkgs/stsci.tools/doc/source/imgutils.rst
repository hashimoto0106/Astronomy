********************
Image Access Modules
********************
These modules all provide the capability to access sections of a FITS image 
using a scrolling buffer. 
   
.. automodule:: stsci.tools.iterfile
   :members:
