********
FITSDIFF
********
This module serves as a large library of helpful file operations, both for 
I/O of files and to extract information about the files. 

.. automodule:: stsci.tools.fitsdiff
   :members:

