*******
WCSUTIL
*******
The `wcsutil` module provides a stand-alone implementation of a WCS object which provides a number of basic transformations and query methods.  Most (if not all) of these functions can be obtained from the use of the PyWCS or STWCS WCS object if those packages have been installed.

.. automodule:: stsci.tools.wcsutil
   :members:
   :undoc-members:
