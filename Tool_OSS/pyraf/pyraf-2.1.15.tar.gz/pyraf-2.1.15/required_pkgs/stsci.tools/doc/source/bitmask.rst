*********************************************************
Utility functions for handling bit masks and mask arrays.
*********************************************************

.. moduleauthor:: Mihai Cara <help@stsci.edu>

.. currentmodule:: stsci.tools.bitmask

.. automodule:: stsci.tools.bitmask
   :members:
