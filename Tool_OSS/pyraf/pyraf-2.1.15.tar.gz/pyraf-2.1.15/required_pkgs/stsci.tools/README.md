# stsci.tools

[![Build Status](https://travis-ci.org/spacetelescope/stsci.tools.svg?branch=master)](https://travis-ci.org/spacetelescope/stsci.tools)
[![Documentation Status](https://readthedocs.org/projects/stscitools/badge/?version=latest)](http://stscitools.readthedocs.io/en/latest/?badge=latest)

STScI utility functions.
