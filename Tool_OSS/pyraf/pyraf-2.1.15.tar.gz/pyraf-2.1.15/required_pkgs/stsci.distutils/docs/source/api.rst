API documentation
=================

stsci.distutils.hooks
---------------------
.. automodule:: stsci.distutils.hooks
   :members:

stsci.distutils.svnutils
------------------------
.. automodule:: stsci.distutils.svnutils
   :members:

stsci.distutils.versionutils
----------------------------
.. automodule:: stsci.distutils.versionutils
   :members:
