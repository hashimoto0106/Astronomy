PyRAF
=====

.. image:: https://ssbjenkins.stsci.edu/buildStatus/icon?job=STScI/pyraf/master
    :target: https://ssbjenkins.stsci.edu/job/STScI/job/pyraf/job/master/
    :alt: Jenkins CI status

PyRAF is a command language for IRAF based on the Python scripting language
that can be used in place of the existing IRAF CL.

For more information on PyRAF - release notes, installation instructions,
the FAQ, tutorials and other documentation, etc. - please visit:

      http://www.stsci.edu/resources/software_hardware/pyraf

If you are in a great hurry and are installing a stand-alone PyRAF download,
visit:

      http://www.stsci.edu/resources/software_hardware/pyraf/pyraf_install_src.html
