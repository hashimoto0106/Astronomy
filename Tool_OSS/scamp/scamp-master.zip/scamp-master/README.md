# SCAMP 

[![Build Status](https://travis-ci.org/astromatic/scamp.svg?branch=master)](https://travis-ci.org/astromatic/scamp)
[![Coverity Scan Build Status](https://scan.coverity.com/projects/scamp/badge.svg)](https://scan.coverity.com/projects/scamp  "Coverity Badge")
[![Documentation Status](https://readthedocs.org/projects/scamp/badge/?version=latest)](http://scamp.readthedocs.io/en/latest/?badge=latest)

a utility that computes astrometric solutions from [SExtractor] catalogs.

Check out the on-line [documentation], the [official web page], and the [user forum].

[SExtractor]: http://astromatic.net/software/sextractor
[documentation]: http://scamp.readthedocs.org
[official web page]: http://astromatic.net/software/scamp
[user forum]: http://astromatic.net/forum/forumdisplay.php?fid=6

