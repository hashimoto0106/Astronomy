.. SCAMP documentation master file, created by
   sphinx-quickstart on Tue Sep 27 15:11:21 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

=================
SCAMP User Manual
=================

Contents
--------

.. toctree::
   :numbered:
   :maxdepth: 2

   Introduction
   Installing
   Using
   Output
   references

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

