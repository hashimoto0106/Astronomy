# EVALUATE definitions

define	EVL_STRLEN	99			# Length of strings
define	EVL_LEN		50			# Parameters structure length

define	EVL_MAGZERO	Memc[P2C($1+$2-1)]	# Magnitude zero point
