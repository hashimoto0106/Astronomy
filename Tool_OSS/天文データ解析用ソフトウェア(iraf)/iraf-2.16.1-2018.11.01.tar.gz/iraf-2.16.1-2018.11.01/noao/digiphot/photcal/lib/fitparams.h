# Define the weighting options.

define	FWT_OPTIONS	"|uniform|photometric|equations|"

define	FWT_UNIFORM	1
define	FWT_PHOTOMETRIC	2
define	FWT_EQUATIONS	3
