# Definitions for IMSUM

define	IMS_MAX		15	# Maximum number of images which are mapped
				# at the same time.
