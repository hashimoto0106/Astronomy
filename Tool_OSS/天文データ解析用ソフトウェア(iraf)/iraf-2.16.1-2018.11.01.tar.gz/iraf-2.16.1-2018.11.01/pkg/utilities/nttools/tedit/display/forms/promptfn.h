# PROMPTFN.H -- Data structure associated with promptfn()

define	LEN_PRSTRUCT	3

define	PR_START	Memi[$1]	# Start flag
define	PR_ROW		Memi[$1+1]	# Cursor row
define	PR_COL		Memi[$1+2]	# Cursor column
