# Definitions for the interactive curve fitting package.

define	IC_XMIN		1
define	IC_XMAX		2
define	IC_SAMPLE	3
define	IC_NAVERAGE	4
define	IC_FUNCTION	5
define	IC_ORDER	6
define	IC_LOWREJECT	7
define	IC_HIGHREJECT	8
define	IC_NITERATE	9
define	IC_GROW		10
define	IC_REJPTS	11
define	IC_NREJECT	12
