/* XPM */
static char * diamond0m [] = {
/* width height ncolors cpp [x_hot y_hot] */
"17 17 3 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s topShadowColor	m white	c #c8c8c8c8c8c8",
"X	s bottomShadowColor	m black	c #646464646464",
/* pixels */
"                 ",
"       ...       ",
"      .. ..      ",
"     ..   ..     ",
"    ..     ..    ",
"   ..       ..   ",
"  ..         ..  ",
" ..           .. ",
" .             . ",
" XX           XX ",
"  XX         XX  ",
"   XX       XX   ",
"    XX     XX    ",
"     XX   XX     ",
"      XX XX      ",
"       XXX       ",
"                 "};
