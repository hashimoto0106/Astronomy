/* XPM */
static char * diamond1s [] = {
/* width height ncolors cpp [x_hot y_hot] */
"17 17 4 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s bottomShadowColor	m black	c #646464646464",
"X	s topShadowColor	m white	c #c8c8c8c8c8c8",
"o	s highlightColor	m black	c black",
/* pixels */
"                 ",
"                 ",
"       ...       ",
"      ..o..      ",
"     ..ooo..     ",
"    ..ooooo..    ",
"   ..ooooooo..   ",
"  ..ooooooooo..  ",
"  .ooooooooooo.  ",
"  XXoooooooooXX  ",
"   XXoooooooXX   ",
"    XXoooooXX    ",
"     XXoooXX     ",
"      XXoXX      ",
"       XXX       ",
"                 ",
"                 "};
