/* XPM */
static char * square1 [] = {
/* width height ncolors cpp [x_hot y_hot] */
"15 15 3 1 0 0",
/* colors */
" 	s bottomShadowColor	m black	c #646464646464",
".	s topShadowColor	m white	c #c8c8c8c8c8c8",
"X	s foreground	m white	c white",
/* pixels */
"              .",
"             ..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
" ..............",
"..............."};
